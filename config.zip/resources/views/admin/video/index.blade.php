@extends('layouts.backend.master')

@section('title', 'Video')

@section('content')
    <div class="container-xl">
        <div class="row">

        </div>
    </div>
@endsection
