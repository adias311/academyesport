<div class="alert alert-danger">
    {{ $title }}
    <br>
    <a href="{{ $url }}">
        <i class="fas fa-{{ $icon }}"></i> {{ $subTitle }}
    </a>
</div>
