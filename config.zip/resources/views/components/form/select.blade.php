<div class="mb-3">
    <div class="form-label">{{ $title }}</div>
    <select class="form-select" name="{{ $name }}">
        {{ $slot }}
    </select>
</div>
