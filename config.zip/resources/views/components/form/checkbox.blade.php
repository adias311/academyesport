<div class="mb-3">
    <div class="form-label">{{ $title }}</div>
    <div>
        {{ $slot }}
    </div>
</div>
