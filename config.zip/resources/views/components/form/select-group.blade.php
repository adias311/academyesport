<div class="mb-3">
    <label class="form-label">
        {{ $title }}
    </label>
    <div class="form-selectgroup">
        {{ $slot }}
    </div>
</div>
