<a href="#" class="text-teal mr-2" data-toggle="modal" data-target="#modal-simple{{ $id }}">
    <i class="fas fa-edit mr-1"></i>
    {{ $title }}
</a>
