<a href="{{ $url }}" {{ $attributes->merge(['class' => '']) }}>
    <i class=" fas fa-{{ $icon }} mr-2"></i>
    {{ $title }}
</a>
