<div class="list-group card-list-group">
    {{ $slot }}
</div>
