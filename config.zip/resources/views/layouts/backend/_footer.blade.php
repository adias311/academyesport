<footer class="footer footer-transparent">
    <div class="container">
        <div class="row text-center align-items-center flex-row-reverse">
            <div class="col-12 col-lg-auto mt-3 mt-lg-0">
                Copyright © {{ date('Y') }}
            </div>
        </div>
    </div>
</footer>
